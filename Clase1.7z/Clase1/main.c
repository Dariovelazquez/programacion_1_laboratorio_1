#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1;
    int num2;
    int resultado;
    char respuesta;

    do
        {
            printf("Ingrese el primer numero:\n");
            scanf("%d",&num1);
            printf("Ingrese el segundo numero:\n");
            scanf("%d",&num2);
            if (num1 > 0 && num2 > 0)
            {
                resultado = num1 + num2;
                printf("\nEl resultado es: %d", resultado);
            }
            else if (num1 > 0 && num2 <= 0)
            {
                printf("\nError en el segundo numero");
            }
            else if (num1 <= 0 && num2 > 0)
            {
                printf("\nError en el primer numero");
            }
            else
            {
                printf("FATAL ERROR!");
            }
            printf("\nDesea continuar s/n?:");
            fflush(stdin);  //borra el buffer de memoria, sirve para ingresar un caracter
            scanf("%c", &respuesta);
        } while( respuesta == 's');

    return 0;
}
